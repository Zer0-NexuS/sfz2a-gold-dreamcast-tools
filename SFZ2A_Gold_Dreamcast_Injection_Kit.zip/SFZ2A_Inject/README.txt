SFZ2 ALPHA DREAMCAST — ROM INJECTION KIT
v1.4.3 RC Projectiles / Disc ID SLG-143P3

WINDOWS 10/11 (64-BIT)
1. Extract this entire ZIP to a normal folder. Do not run it inside the ZIP.
2. Drag your matching modified sfz2ald.zip onto BUILD_CDI.bat.
3. Wait for SUCCESS. Your CDI appears in the output folder.

No SDK, compiler, Python installation, administrator access or internet
connection is needed. Keep at least 1 GB free on the output drive.
The included Windows runtime stays inside this folder.

WHICH ROM?
This kit requires the exact modified ROM revision used by RC P3, including
the added character. Retail Street Fighter Alpha 2 / Zero 2 Alpha / Gold
ROM sets and earlier revisions are not interchangeable.

The original matching ZIP's SHA256 is:
8e3a846a46e210e4c1fea7b71cd56c36e942ad4c5b5b36c5e92b37147484cefb

Repacked ZIPs are accepted: all 19 required member contents must match.
Names can differ in capitalization or be inside a subfolder. Additional
README files are ignored. A missing, changed or duplicated ROM member
stops the build with its name. Checksums are never bypassed.
Per-member SHA256 values are in data/manifest.json. The ROM is not supplied,
downloaded, modified or replaced by this kit.

WHAT IT DOES
The tool validates your ROM, normalizes its ZIP metadata, generates the
graphics cache and the release's optimized graphics pack, injects those
files into a ROM-free disc template, and generates CD error correction.
It then checks the SHA256 of the complete CDI against the tested release.
This preserves the existing game, audio, menus, VMU art and optimizations.

The resulting CDI is byte-for-byte identical to RC P3:
d893907001bbf567753a4d93dfbe3fe0bbc9cbd5a4d688cb7a5f4de8cc1e91de

Cold-boot the CDI in Flycast or use it for a compatible Dreamcast disc.
An emulator's old whole-machine save state can retain an older build.

OUTPUT AND ERRORS
An unrelated existing output file is not replaced. A previously generated
verified CDI is reused. Temporary generated ROM/cache files are removed
after success or failure; your input ZIP is left untouched. Interrupted
builds may leave a .partial file or .slg-build- temporary folder; these can be
deleted and are not a finished CDI.
Run logs are kept in logs. The program prints progress during each stage.

MAC / LINUX
With Python 3.11 or later installed, run:
  bash BUILD_CDI.sh /path/to/sfz2ald.zip
Or:
  python3 tools/inject.py /path/to/sfz2ald.zip --output /path/to/game.cdi
Only the Python standard library is needed. The output checksum must match;
a different compressor implementation that changes the bytes will stop.

SOURCE AND TESTING
source.zip contains the matching Dreamcast program source and build inputs,
excluding the ROM and its generated game graphics caches. The injector's
Python source is directly available in tools. Runtime license information
is in runtime/LICENSE.txt; provenance and test results are in TESTING.txt.
