#!/usr/bin/env bash
set -eu
builder_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then
  echo 'Usage: bash BUILD_CDI.sh /path/to/matching/sfz2ald.zip'
  exit 2
fi
exec python3 "$builder_dir/tools/inject.py" "$1"
