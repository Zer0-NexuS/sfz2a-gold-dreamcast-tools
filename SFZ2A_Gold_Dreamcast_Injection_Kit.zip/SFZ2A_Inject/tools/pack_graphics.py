#!/usr/bin/env python3
"""Convert an NJEMU raw graphics cache to the Dreamcast resident format.
Uses the Python standard library. ROM graphics size is the original ROM region,
not the driver's compact cache size. Example: ... sfz2ald.cache sfz2ald.dcg 0x1400000
"""
import argparse
import struct
from pathlib import Path
import zlib
import json

def build(src, dst, gfx_size, ram_priority=None, section_size=8192, fast_pages=None):
    raw = Path(src).read_bytes()
    usage = min((gfx_size - 0x800000) >> 6, 65536) + (gfx_size >> 7) + min((gfx_size - 0x800000) >> 9, 65536)
    offsets = struct.unpack_from('<512I', raw, 8 + usage)
    payload, index = bytearray(), [(0, 0)] * len(offsets)
    populated = 0
    priority = [] if ram_priority is None else json.loads(Path(ram_priority).read_text())
    if len(priority) != len(set(priority)) or any(not isinstance(b, int) or b < 0 or b >= 512 for b in priority):
        raise ValueError('Invalid RAM priority block list')
    fast = set() if fast_pages is None else set(json.loads(Path(fast_pages).read_text()))
    if section_size != 8192 and fast:
        raise ValueError('Fast pages require the 8KB format')
    if any(not isinstance(k, int) or k < 0 or k >= 4096 for k in fast):
        raise ValueError('Invalid fast-page key')
    hot = set(priority)
    # The existing loader places the prefix in spare VRAM and the tail in
    # main RAM. Keep frequently used graphics at the tail so those decodes
    # bypass the VRAM-to-staging copy. No format or resident-size change.
    order = [b for b in range(len(offsets)) if b not in hot] + priority
    for b in order:
        offset = offsets[b]
        if offset == 0xffffffff: continue
        block = raw[offset:offset + 65536]
        if len(block) != 65536:
            raise ValueError('Truncated source graphics block')
        # Independently checksummed sections bound a new-tile demand load.
        # Keep logical 64 KiB bank IDs and the existing RAM/VRAM layout.
        # Measured cold impact bursts use stored DEFLATE sections: same
        # lossless zlib format and checksum, less SH-4 decode work. Other
        # sections retain level 9 to protect the resident memory budget.
        sections = [zlib.compress(block[i:i + section_size],
                                  level=0 if (b * 8 + i // section_size) in fast else 9)
                    for i in range(0, 65536, section_size)]
        packed = (struct.pack('<8H', *(len(s) for s in sections)) + b''.join(sections)
                  if section_size == 8192 else sections[0])
        if len(packed) > 65536:
            raise ValueError('Block does not fit the staging buffer')
        assert b''.join(zlib.decompress(s) for s in sections) == block
        index[b] = (len(payload), len(packed))
        payload.extend(packed)
        payload.extend(b'\0' * (-len(payload) % 4))
        populated += 1
    header = bytearray(struct.pack('<8sIII', b'CPS2DCG3' if section_size == 8192 else b'CPS2DCG1', populated * 65536, len(payload), 512))
    header.extend(b''.join(struct.pack('<II', *v) for v in index))
    header.extend(b'\0' * (6144 - len(header)))
    Path(dst).write_bytes(header + payload)
    print(f'{populated} blocks verified; compressed payload {len(payload)} bytes')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source'); p.add_argument('destination'); p.add_argument('gfx_size', type=lambda s: int(s, 0))
    p.add_argument('--ram-priority', type=Path, help='JSON block IDs, highest priority last')
    p.add_argument('--section-size', type=int, choices=(8192,65536), default=8192)
    p.add_argument('--fast-pages', type=Path, help='JSON 8KB page keys measured on cold impact spikes')
    a = p.parse_args(); build(a.source, a.destination, a.gfx_size, a.ram_priority,a.section_size,a.fast_pages)
