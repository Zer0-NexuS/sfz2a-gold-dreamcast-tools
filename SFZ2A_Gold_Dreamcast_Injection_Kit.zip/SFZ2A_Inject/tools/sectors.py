"""CD-ROM Mode 2 Form 1 sectors, stored without the 16-byte sync/MSF header."""
import struct

def tables():
    forward=[];back=[0]*256;edc=[]
    for i in range(256):
        j=(i<<1)^ (0x11d if i&128 else 0)
        forward.append(j);back[i^j]=i
        x=i
        for _ in range(8):x=(x>>1)^(0xd8018001 if x&1 else 0)
        edc.append(x)
    return forward,back,edc
F,B,E=tables()

def parity(data,major,minor,mult,inc):
    size=major*minor;out=bytearray(major*2);f,b=F,B
    for m in range(major):
        index=(m>>1)*mult+(m&1);a=c=0
        for _ in range(minor):
            value=data[index];index+=inc
            if index>=size:index-=size
            a^=value;c^=value;a=f[a]
        a=b[f[a]^c];out[m]=a;out[m+major]=a^c
    return out

def make_sector(header,payload):
    if len(header)!=8 or len(payload)!=2048:raise ValueError('Invalid sector input')
    body=header+payload;edc=0;e=E
    for x in body:edc=(edc>>8)^e[(edc^x)&255]
    body+=struct.pack('<I',edc)
    source=bytes(4)+body
    p=parity(source,86,24,2,86)
    return body+p+parity(source+p,52,43,86,88)
