"""Offline, checksum-locked reconstruction of the verified Dreamcast release."""
from pathlib import Path,PurePosixPath
import argparse,datetime,hashlib,json,os,shutil,sys,tempfile,time,traceback,zipfile,zlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from build_cache import build as build_cache
from pack_graphics import build as pack_graphics
from sectors import make_sector
ROOT=Path(__file__).resolve().parents[1]

class BuildError(Exception):pass
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check_file(path,expected,label):
    if path.stat().st_size!=expected['bytes'] or sha(path)!=expected['sha256']:
        raise BuildError(label+' differs from the verified release. No image was published.')

def normalize(source,target,m,log):
    if source.stat().st_size>128*1024*1024:raise BuildError('ROM ZIP exceeds the supported size (128 MB).')
    members={}
    with zipfile.ZipFile(source) as z:
        wanted={x['name'].casefold() for x in m['members']}
        for i in z.infolist():
            if i.is_dir():continue
            name=PurePosixPath(i.filename.replace('\\','/')).name.casefold()
            if name not in wanted:continue
            if name in members:raise BuildError('Duplicate ROM member: '+name)
            members[name]=i
        issues=[]
        for entry in m['members']:
            i=members.get(entry['name'].casefold())
            if i is None:issues.append(entry['name']+': missing');continue
            if i.flag_bits&1 or i.file_size!=entry['size']:
                issues.append(entry['name']+': wrong size or encrypted');continue
            if hashlib.sha256(z.read(i)).hexdigest()!=entry['sha256']:issues.append(entry['name']+': wrong revision')
        if issues:raise BuildError('ROM does not match this release:\n  '+'\n  '.join(issues)+'\nUse the matching modified SFZ2A ROM; retail Alpha 2/Gold sets are not interchangeable.')
        log('  All 19 required ROM members match.')
        with zipfile.ZipFile(target,'w') as dst:
            dst.comment=bytes.fromhex(m['zip_comment'])
            for entry in m['members']:
                meta=entry['info'];info=zipfile.ZipInfo(entry['name'],tuple(meta['date_time']))
                for k in ('create_system','create_version','extract_version','reserved','volume','internal_attr','external_attr'):setattr(info,k,meta[k])
                info.extra=bytes.fromhex(meta['extra']);info.comment=bytes.fromhex(meta['comment'])
                dst.writestr(info,z.read(members[entry['name'].casefold()]),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    check_file(target,next(x for x in m['files'] if x['name']=='sfz2ald.zip'),'Normalized ROM ZIP')

def run(source,output,log):
    m=json.loads((ROOT/'data/manifest.json').read_text());template=ROOT/'data/template.cdi.zlib'
    if sha(template)!=m['template_sha256']:raise BuildError('The builder template is damaged. Extract a fresh copy of the package.')
    if not source.is_file():raise BuildError('Drop one matching ROM ZIP onto BUILD_CDI.bat.')
    output.parent.mkdir(parents=True,exist_ok=True)
    if output.resolve()==source.resolve():raise BuildError('Output cannot overwrite the input ROM.')
    # Reserve room for one 740 MB image, temporary caches and a practical margin.
    if not output.exists() and shutil.disk_usage(output.parent).free<m['image_bytes']+160*1024*1024:
        raise BuildError('At least 1 GB of free space is required on the output drive.')
    partial=None
    with tempfile.TemporaryDirectory(prefix='.slg-build-',dir=output.parent) as td:
        work=Path(td);rom=work/'sfz2ald.zip'
        log('[1/6] Checking the ROM and normalizing its ZIP container...')
        normalize(source,rom,m,log)
        if output.exists():
            if output.stat().st_size==m['image_bytes'] and sha(output)==m['image_sha256']:
                log('The existing CDI already matches the verified release.');return output
            raise BuildError('An unrelated file already exists at '+str(output)+'. Move it or choose another output name.')
        try:
            log('[2/6] Generating the graphics cache...')
            cache=work/'sfz2ald.cache';build_cache(rom,cache,log)
            check_file(cache,next(x for x in m['files'] if x['name']=='sfz2ald.cache'),'Graphics cache')
            log('[3/6] Packing the release graphics optimizations...')
            packed=work/'sfz2ald.dcg'
            pack_graphics(cache,packed,0x1400000,ROOT/'data/graphics_ram_priority.json',fast_pages=ROOT/'data/graphics_fast_pages.json')
            check_file(packed,next(x for x in m['files'] if x['name']=='sfz2ald.dcg'),'Packed graphics (use the bundled Windows runtime)')
            fd,name=tempfile.mkstemp(prefix='.'+output.stem+'-',suffix='.partial',dir=output.parent);partial=Path(name)
            log('[4/6] Reconstructing the disc layout...')
            d=zlib.decompressobj();written=0
            with os.fdopen(fd,'wb') as dst,template.open('rb') as src:
                while block:=src.read(1024*1024):
                    while block:
                        chunk=d.decompress(block,4*1024*1024);block=d.unconsumed_tail;written+=len(chunk)
                        if written>m['image_bytes']:raise BuildError('Template expands beyond its declared size.')
                        dst.write(chunk)
                chunk=d.flush();dst.write(chunk);written+=len(chunk)
            if not d.eof or d.unused_data or written!=m['image_bytes']:raise BuildError('Incomplete disc template.')
            log('[5/6] Injecting ROM and graphics; generating disc error correction...')
            with partial.open('r+b') as dst:
                for entry in m['files']:
                    log('  '+entry['name'])
                    with (work/entry['name']).open('rb') as src:
                        for index in range(entry['sectors']):
                            pos=entry['offset']+index*2336;dst.seek(pos);header=dst.read(8)
                            sector=make_sector(header,src.read(2048).ljust(2048,b'\0'))
                            dst.seek(pos);dst.write(sector)
                            if index and index%3000==0:log('    '+str(index)+' / '+str(entry['sectors'])+' sectors')
            log('[6/6] Verifying the complete CDI...')
            if partial.stat().st_size!=m['image_bytes'] or sha(partial)!=m['image_sha256']:
                raise BuildError('Final CDI checksum failed. No image was published.')
            # Recheck before publication to preserve a concurrently created file.
            if output.exists():raise BuildError('Output appeared during the build; it was not overwritten.')
            partial.rename(output);partial=None
            log('SUCCESS: byte-for-byte verified CDI — '+m['disc_id'])
            log('Output: '+str(output));return output
        finally:
            if partial is not None:partial.unlink(missing_ok=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('rom',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();logs=ROOT/'logs';logs.mkdir(exist_ok=True)
    with (logs/('build-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.log')).open('w',encoding='utf8') as f:
        def log(s):print(s,flush=True);f.write(s+'\n');f.flush()
        log('SLG SFZ2A — v1.4.3 RC P3 offline CDI builder')
        start=time.monotonic()
        try:
            run(a.rom.resolve(),(a.output or ROOT/'output'/json.loads((ROOT/'data/manifest.json').read_text())['output_name']).resolve(),log)
            log('Completed in '+str(round(time.monotonic()-start,1))+' seconds.');return 0
        except (BuildError,OSError,ValueError,zipfile.BadZipFile) as error:
            log('BUILD STOPPED: '+str(error));return 1
        except Exception:
            log(traceback.format_exc());return 1
if __name__=='__main__':raise SystemExit(main())
