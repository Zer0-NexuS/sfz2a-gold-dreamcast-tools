"""Standard-library version of the release's byte-exact CPS2 cache converter."""
from pathlib import Path
import struct
import zipfile

REGION=0x1400000
LAYOUT=(("sz2.13m",0,0x400000),("sz2.15m",2,0x400000),
 ("sz2.17m",4,0x400000),("sz2.19m",6,0x400000),
 ("sz2.14m",0x1000000,0x100000),("sz2.16m",0x1000002,0x100000),
 ("sz2.18m",0x1000004,0x100000),("sz2.20m",0x1000006,0x100000))
TRANSPARENT=bytes((b&15==15)+(b>>4==15) for b in range(256))
PLANES=[sum(((b>>(7-n))&1) << ((n%4)*8+(4 if n>=4 else 0)) for n in range(8)) for b in range(256)]

def classify(tile):
    count=sum(tile.translate(TRANSPARENT))
    return 0 if count==len(tile)*2 else 1 if not count else 2

def build(source,output,progress=print):
    gfx=bytearray(REGION)
    with zipfile.ZipFile(source) as z:
        for name,offset,size in LAYOUT:
            raw=z.read(name)
            if len(raw)!=size:raise ValueError('Incorrect graphics member size: '+name)
            end=offset+len(raw)*4
            gfx[offset:end:8]=raw[::2]
            gfx[offset+1:end:8]=raw[1::2]
        program=b''.join(z.read(n) for n in ('szaad.03','szaad.04','szaa.05','szaa.06','szaa.07','szaa.08'))
    for start in range(0,REGION,0x200000):
        block=gfx[start:start+0x200000]
        for col in range(8):
            gfx[start+col:start+0x100000:8]=block[col::16]
            gfx[start+0x100000+col:start+0x200000:8]=block[col+8::16]
    progress('  Decoding graphics tiles...')
    out=bytearray(REGION);pack=struct.pack_into;lut=PLANES
    for i in range(0,REGION,4):
        pack('<I',out,i,lut[gfx[i]]|(lut[gfx[i+1]]<<1)|(lut[gfx[i+2]]<<2)|(lut[gfx[i+3]]<<3))
    gfx=out
    u8=bytearray(0x10000);u16=bytearray(0x28000);u32=bytearray(0x6000)
    for code,off in enumerate(range(0x800000,0x920000,64)):
        u8[code]=classify(b''.join(gfx[off+y*8+4:off+y*8+8] for y in range(8)))
    for first,last in ((0,0x800000),(0xa40000,REGION)):
        for off in range(first,last,128):u16[off>>7]=classify(gfx[off:off+128])
    for code,off in enumerate(range(0x920000,0xa40000,512),0x900):
        u32[code]=classify(gfx[off:off+512])
    if program[0xf9000:0xf9004]==b'\x00\x0c\x7d\x00':
        ids=set(struct.unpack_from('<256H',program,0xf9502)[::2])
        if not ids or any(c>=0x6000 for c in ids):raise ValueError('Invalid title map')
        for code in ids:
            off=0x800000+code*512;u32[code]=classify(gfx[off:off+512])
    offsets=[0xffffffff]*512;payload=bytearray();blank=b'\xff'*65536
    for bank,off in enumerate(range(0,REGION,65536)):
        block=gfx[off:off+65536]
        if block!=blank:offsets[bank]=0x40000+len(payload);payload.extend(block)
    header=bytearray(b'CPS2V23\0')+u8+u16+u32+struct.pack('<512I',*offsets)
    header.extend(bytes(0x40000-len(header)))
    Path(output).write_bytes(header+payload)
    progress('  Graphics cache generated.')
