@echo off
setlocal DisableDelayedExpansion
title SLG SFZ2A Dreamcast CDI Builder
if not "%~2"=="" goto many
if "%~1"=="" goto usage
if not exist "%~dp0runtime\python.exe" goto missing
"%~dp0runtime\python.exe" -I "%~dp0tools\inject.py" "%~1"
set "build_result=%errorlevel%"
echo.
if not "%build_result%"=="0" echo Build stopped. See the message above and the logs folder.
echo Press any key to close this window.
pause >nul
exit /b %build_result%
:usage
echo Extract this entire package first.
echo Drag the matching sfz2ald.zip onto BUILD_CDI.bat.
echo The verified CDI will be saved in the output folder.
echo.
pause
exit /b 2
:many
echo Please drop only one matching ROM ZIP at a time.
pause
exit /b 2
:missing
echo The bundled runtime is missing. Extract the entire package again.
pause
exit /b 2
